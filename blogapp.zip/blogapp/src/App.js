import logo from './logo.svg';
import './App.css';
import SignIn from './components/auth/SignIn';
import SignUp from './components/auth/SignUp';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import BlogLists from './components/BlogLists';
import BlogDetails from './components/BlogDetails';

function App() {
  // 
  
  // return (
  //   <BrowserRouter>
  //   <Router>
  //     {/* <Routes>
  //       <Route exact path="/" component={BlogList} />
  //       {/* <Route exact path="/my-posts" component={MyBlogPosts} />
  //       <Route exact path="/posts/:postId" component={BlogPost} /> */}
  //     {/* </Routes> */}
  //   {/* // </Router> */} */ 

  //   <Route path="/" exact component={BlogList} />
  //    {/* <Route path="/about" component={About} />
  //   <Route path="/contact" component={Contact} /> */}
  // </Router>
  // </BrowserRouter>
  // );

  // return (
  //   <Router>
  //     <Switch>
  //       <Route exact path="/" component={BlogLists} />
  //       {/* <Route exact path="/my-posts" component={MyBlogPosts} />
  //       <Route exact path="/posts/:postId" component={BlogPost} /> */}
  //     </Switch>
  //   </Router>
  // );

  return (
    <Router>
    <Routes>
        <Route exact path="/" element={<BlogLists />} />
        <Route path="/blogDetails" element={<BlogDetails />} />
        <Route path="/signIn" element={<SignIn />} />
        <Route path="/signUp" element={<SignUp />} />
        {/* <Route path="/my-posts" element={<MyBlogPosts />} /> */}
        {/* <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} /> */}
      </Routes>
    </Router>
  )

      }
export default App;