import React, { useEffect, useState } from 'react';
import { Link, Route, Router } from 'react-router-dom';
import './BlogDetails.css';

const BlogDetails = () => {
    const [blogDetails, setBlogDetails] = useState([]);
    const searchParam = new URLSearchParams(window.location.search);
    const userId = searchParam.get('userId');
    const postId = searchParam.get('postId');
    console.log('*******************',searchParam.get('userId'));
    console.log('*******post1********',searchParam.get('postId'));
    useEffect(() => {
      fetch(`https://jsonplaceholder.typicode.com/users/${userId}/posts?id=${postId}`)
        .then(response => response.json())
        .then(data => console.log(setBlogDetails(data)))
        .catch(error => console.log(error));
    }, []);


    return (
        <div>
          <h1>Blog Details</h1>
          {blogDetails.map(post => (
            <div key={post.id} className='details'>
              <p>{post.body}</p>
            </div>
          ))}
        </div>
      );
    };

    export default BlogDetails;