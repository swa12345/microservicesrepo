// BlogList.js
import React, { useEffect, useState } from 'react';
import { Link, Route, Router } from 'react-router-dom';
import './BlogList.css';

const BlogList = () => {
  const [blogPosts, setBlogPosts] = useState([]);
  const searchParam = new URLSearchParams(window.location.search);
  console.log('*******************',searchParam.get('userId'));
  console.log('*******post********',searchParam.get('postId'));
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => setBlogPosts(data))
      .catch(error => console.log(error));
  }, []);

//   ++++++++++++++++++++++++++

//   const postByUserIdandPostIdUrl=`https://jsonplaceholder.typicode.com/users/${userId}/posts?id=${postId}`

 

  return (
    <div className='container'>
      <h1>Blog Posts</h1>
      {blogPosts.map(post => (
        <div key={post.id} className='link'>
          <Link to={`/blogDetails?postId=${post.id}&userId=${post.userId}`}>{post.title}</Link><br />
        </div>
      ))}
    </div>
  );
};

export default BlogList;
