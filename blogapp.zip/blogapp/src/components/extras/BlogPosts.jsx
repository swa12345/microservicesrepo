// import React, { useEffect, useState } from 'react';

// const BlogPosts = () => {
//   const [posts, setPosts] = useState([]);

//   useEffect(() => {
//     // Fetch blog posts from an API
//     fetch('https://jsonplaceholder.typicode.com/posts')
//       .then(response => response.json())
//       .then(data => setPosts(data.posts))
//       .catch(error => console.log(error));
//     // console.log(posts.length);

//   }, []);


//   return (
//     // <div>
//     //   <h1>Blog Posts</h1>
//     //   {posts?.map(post => (
//     //       <div key={post.it}>
//     //         <p>{post.userId}</p>
//     //         <p>{post.it}</p>
//     //         <h2>{post.title}</h2>
//     //         <p>{post.body}</p>
//     //       </div>
//     //   ))}
//     // </div>

//     <div>
//       <h1>Blog Posts</h1>
//       {posts?.length > 0 ? (
//         posts?.map(post => (
//           <div key={post.it}>
//               <p>{post.userId}</p>
//               <p>{post.it}</p>
//               <h2>{post.title}</h2>
//               <p>{post.body}</p>
//           </div>
//         ))
//       ) : (
//         <p>Loading blog posts...</p>
//       )}
//     </div>
//   );
// };

// export default BlogPosts;
